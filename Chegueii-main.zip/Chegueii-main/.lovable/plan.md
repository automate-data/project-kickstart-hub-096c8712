

## Problema

O template do Twilio tem uma URL base fixa no botao e concatena a variavel `{{4}}` como sufixo. Ao enviar uma URL completa em `{{4}}`, o resultado e uma URL duplicada e quebrada.

**Antes (funcionava):** template envia `prefixo_fixo + filename` -> URL valida
**Agora (quebrado):** template envia `prefixo_fixo + URL_completa` -> URL duplicada

## Solucao

Restaurar o comportamento original sem alterar o template:

1. **Tornar o bucket `package-photos` publico para leitura** - isso permite que a URL publica gerada pelo template funcione diretamente
2. **Enviar apenas o nome do arquivo** como variavel `{{4}}` na funcao `send-whatsapp`

A seguranca de upload continua protegida pelas politicas de acesso existentes. As fotos sao nomeadas com timestamps unicos, tornando-as praticamente impossiveis de adivinhar.

## Detalhes tecnicos

### 1. Tornar o bucket publico

Executar via migracao SQL:

```text
UPDATE storage.buckets SET public = true WHERE id = 'package-photos';
```

### 2. Atualizar `supabase/functions/send-whatsapp/index.ts`

Reverter a variavel `{{4}}` para enviar apenas o nome do arquivo:

```text
Antes:  const photoUrl = `${supabaseUrl}/functions/v1/view-photo?file=...`
Depois: const photoUrl = photo_filename
```

### 3. Manter a Edge Function `view-photo`

Ela continua util para outros cenarios (acesso direto sem o template), mas nao sera mais usada pelo fluxo do WhatsApp.

### Arquivos modificados

- `supabase/functions/send-whatsapp/index.ts` - reverter variavel 4 para apenas filename
- Migracao SQL para tornar o bucket publico

