import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Resident, AISuggestion } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Camera, Loader2, ArrowLeft, Check, Sparkles, Search, X } from 'lucide-react';
import { processImageForWhatsApp } from '@/lib/imageProcessor';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

type Step = 'capture' | 'processing' | 'confirm';

export default function ReceivePackage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [step, setStep] = useState<Step>('capture');
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Form data
  const [residents, setResidents] = useState<Resident[]>([]);
  const [selectedResident, setSelectedResident] = useState<Resident | null>(null);
  const [carrier, setCarrier] = useState('');
  const [notes, setNotes] = useState('');
  const [aiSuggestion, setAiSuggestion] = useState<AISuggestion | null>(null);
  const [ocrRawText, setOcrRawText] = useState<string | null>(null);
  const [residentSearchOpen, setResidentSearchOpen] = useState(false);

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const fetchResidents = useCallback(async (): Promise<Resident[]> => {
    const { data } = await supabase
      .from('residents')
      .select('*')
      .eq('is_active', true)
      .order('full_name');
    
    if (data) {
      const residentsData = data as Resident[];
      setResidents(residentsData);
      return residentsData;
    }
    return [];
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraOpen(false);
  }, []);

  const openCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      setIsCameraOpen(true);
    } catch (err) {
      console.error('[Camera] getUserMedia failed:', err);
      // Fallback: open file input without capture
      fileInputRef.current?.click();
    }
  }, []);

  const capturePhoto = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0);
    
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      
      stopCamera();
      
      const file = new File([blob], `camera_${Date.now()}.jpg`, { type: 'image/jpeg' });
      setPhotoFile(file);
      const preview = URL.createObjectURL(blob);
      setPhotoPreview(preview);
      
      const residentsData = await fetchResidents();
      await processWithAI(file, residentsData);
    }, 'image/jpeg', 0.9);
  }, [stopCamera, fetchResidents]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setPhotoFile(file);
    const preview = URL.createObjectURL(file);
    setPhotoPreview(preview);
    
    const residentsData = await fetchResidents();
    await processWithAI(file, residentsData);
  };

  const processWithAI = async (file: File, residentsData: Resident[]) => {
    setStep('processing');
    setIsProcessing(true);

    try {
      // Convert image to base64
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          resolve(result.split(',')[1]);
        };
        reader.readAsDataURL(file);
      });

      // Call AI edge function
      const { data, error } = await supabase.functions.invoke('process-label', {
        body: { image_base64: base64 },
      });

      if (error) throw error;

      if (data?.suggestion) {
        const suggestion = data.suggestion;
        console.log('AI Suggestion:', suggestion);
        setAiSuggestion(suggestion);
        setOcrRawText(data.raw_text || null);

        // Try to auto-select resident with improved matching
        const findBestMatch = () => {
          // Normalize text for comparison (remove accents, lowercase)
          const normalizeText = (str: string) => 
            str?.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim() || '';
          
          // Normalize block: extract only the letter from formats like "B01", "BLOCO B", "B-1"
          const normalizeBlock = (block: string): string => {
            if (!block) return '';
            const cleaned = block.toUpperCase().replace(/[^A-Z0-9]/g, '');
            // If starts with letter followed by numbers, get just the letter
            const match = cleaned.match(/^([A-Z])/);
            return match ? match[1] : cleaned;
          };
          
          // Normalize apartment: extract only numbers, remove leading zeros
          const normalizeApartment = (apt: string): string => {
            if (!apt) return '';
            // Extract only numbers
            const numbers = String(apt).replace(/\D/g, '');
            // Remove leading zeros except if it's just "0"
            return numbers.replace(/^0+(?=\d)/, '') || numbers;
          };
          
          const suggestedName = normalizeText(suggestion.resident_name || '');
          const suggestedBlock = normalizeBlock(suggestion.block || '');
          const suggestedApartment = normalizeApartment(suggestion.apartment || '');
          
          console.log('[Matching] Dados sugeridos normalizados:', { 
            name: suggestedName, 
            block: suggestedBlock, 
            apartment: suggestedApartment 
          });
          
          // Score each resident
          let bestMatch: Resident | null = null;
          let bestScore = 0;
          
          for (const resident of residentsData) {
            let score = 0;
            const residentName = normalizeText(resident.full_name);
            const residentBlock = normalizeBlock(resident.block);
            const residentApartment = normalizeApartment(resident.apartment);
            
            // Apartment matching (HIGHEST PRIORITY - exact match is strong indicator)
            if (suggestedApartment && residentApartment) {
              if (residentApartment === suggestedApartment) {
                score += 40; // Exact apartment match is very strong
              } else if (residentApartment.includes(suggestedApartment) || suggestedApartment.includes(residentApartment)) {
                score += 20;
              }
            }
            
            // Block matching
            if (suggestedBlock && residentBlock) {
              if (residentBlock === suggestedBlock) {
                score += 30;
              } else if (residentBlock.includes(suggestedBlock) || suggestedBlock.includes(residentBlock)) {
                score += 15;
              }
            }
            
            // Name matching (flexible - match any significant words)
            if (suggestedName && residentName) {
              // Filter out short words (prepositions like "de", "da", "do", "dos", "das")
              const stopWords = ['de', 'da', 'do', 'dos', 'das', 'e'];
              const suggestedWords = suggestedName.split(' ').filter(w => w.length > 2 && !stopWords.includes(w));
              const residentWords = residentName.split(' ').filter(w => w.length > 2 && !stopWords.includes(w));
              
              // Count matching words (partial matches allowed)
              const matchingWords = suggestedWords.filter(sw => 
                residentWords.some(rw => rw.includes(sw) || sw.includes(rw))
              );
              
              if (matchingWords.length >= 2) {
                score += 35; // Multiple word matches
              } else if (matchingWords.length === 1) {
                score += 20; // Single word match
              }
              
              // Bonus for first name or last name exact match
              if (suggestedWords[0] && residentWords[0] && suggestedWords[0] === residentWords[0]) {
                score += 15; // First name exact match bonus
              }
              const lastSuggested = suggestedWords[suggestedWords.length - 1];
              const lastResident = residentWords[residentWords.length - 1];
              if (lastSuggested && lastResident && lastSuggested === lastResident) {
                score += 15; // Last name exact match bonus
              }
            }
            
            if (score > bestScore) {
              bestScore = score;
              bestMatch = resident;
              console.log('[Matching] Novo melhor match:', resident.full_name, 'Score:', score);
            }
          }
          
          console.log('[Matching] Resultado final:', bestMatch?.full_name || 'Nenhum', 'Score:', bestScore);
          
          // Only return if score is high enough (apartment+block OR strong name match)
          return bestScore >= 35 ? bestMatch : null;
        };
        
        const matchedResident = findBestMatch();
        if (matchedResident) {
          console.log('Matched resident:', matchedResident.full_name);
          setSelectedResident(matchedResident);
        }

        if (suggestion.carrier) {
          setCarrier(suggestion.carrier);
        }
      }
    } catch (error) {
      console.error('AI processing error:', error);
      toast({
        title: 'Não foi possível ler a etiqueta',
        description: 'Selecione o morador manualmente',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
      setStep('confirm');
    }
  };

  const handleSubmit = async () => {
    if (!photoFile || !user) return;

    setIsSaving(true);

    try {
      // 1. Process image for WhatsApp compatibility (JPEG, max 1600px, < 1MB)
      console.log('[Submit] Processing image for WhatsApp...');
      const processedImage = await processImageForWhatsApp(photoFile);
      console.log('[Submit] Image processed:', processedImage);

      // 2. Upload with explicit Content-Type: image/jpeg
      const { error: uploadError } = await supabase.storage
        .from('package-photos')
        .upload(processedImage.fileName, processedImage.blob, {
          contentType: 'image/jpeg',
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // 3. Get signed URL for validation (bucket is private)
      const { data: signedUrlData, error: signedUrlError } = await supabase.storage
        .from('package-photos')
        .createSignedUrl(processedImage.fileName, 3600); // 1 hour validity

      if (signedUrlError || !signedUrlData?.signedUrl) {
        console.error('[Submit] Failed to create signed URL:', signedUrlError);
        throw new Error('Falha ao gerar URL da imagem');
      }

      console.log('[Submit] Signed URL created successfully');

      // 4. Build internal path for database storage (not the full signed URL)
      const photoPath = processedImage.fileName;

      // 5. Save package with photo path (will generate signed URL when viewing)
      const { error: insertError } = await supabase
        .from('packages')
        .insert([{
          resident_id: selectedResident?.id || null,
          photo_url: photoPath,
          carrier: carrier || null,
          ocr_raw_text: ocrRawText,
          ai_suggestion: aiSuggestion as any,
          notes: notes || null,
          received_by: user.id,
        }]);

      if (insertError) throw insertError;

      // 6. Trigger WhatsApp notification only with validated image
      if (selectedResident?.phone) {
        try {
          const registeredBy = user?.user_metadata?.full_name || 'Portaria';
          
          await supabase.functions.invoke('send-whatsapp', {
            body: {
              phone: selectedResident.phone,
              resident_name: selectedResident.full_name,
              registered_by: registeredBy,
              photo_filename: processedImage.fileName,
            },
          });
        } catch (notifError) {
          console.error('WhatsApp notification error:', notifError);
          // Don't fail the whole operation if notification fails
        }
      }

      toast({
        title: 'Encomenda registrada!',
        description: selectedResident?.phone 
          ? 'Morador notificado via WhatsApp' 
          : 'Morador não tem telefone cadastrado',
      });

      navigate('/');
    } catch (error) {
      console.error('Error saving package:', error);
      
      // Check if it's an image validation error
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      if (errorMessage.includes('validação') || errorMessage.includes('imagem')) {
        toast({
          title: 'Erro na imagem',
          description: 'Tire uma nova foto da encomenda',
          variant: 'destructive',
        });
        setStep('capture');
        setPhotoFile(null);
        setPhotoPreview(null);
      } else {
        toast({
          title: 'Erro ao salvar',
          description: 'Tente novamente',
          variant: 'destructive',
        });
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-8rem)] flex flex-col animate-fade-in">
      {/* Hidden fallback file input (no capture attribute) */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Live Camera Viewfinder */}
      {isCameraOpen && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col">
          <video
            ref={(el) => {
              videoRef.current = el;
              if (el && streamRef.current) {
                el.srcObject = streamRef.current;
              }
            }}
            onLoadedMetadata={(e) => {
              (e.target as HTMLVideoElement).play();
            }}
            autoPlay
            playsInline
            muted
            className="flex-1 w-full object-cover"
          />
          
          {/* Close button */}
          <button
            onClick={stopCamera}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Capture button */}
          <div className="absolute bottom-8 left-0 right-0 flex justify-center">
            <button
              onClick={capturePhoto}
              className="w-20 h-20 rounded-full border-4 border-white bg-white/30 active:bg-white/60 transition-colors"
              aria-label="Capturar foto"
            />
          </div>
        </div>
      )}

      {step === 'capture' && !isCameraOpen && (
        <div className="flex-1 flex flex-col items-center justify-center space-y-6 py-8">
          <Button
            onClick={() => navigate('/')}
            variant="ghost"
            className="absolute top-4 left-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Voltar
          </Button>

          <div
            onClick={openCamera}
            className="w-64 h-64 border-2 border-dashed border-primary/50 rounded-3xl flex flex-col items-center justify-center gap-4 cursor-pointer hover:border-primary hover:bg-primary/5 transition-all"
          >
            <Camera className="w-16 h-16 text-primary" />
            <span className="text-lg font-medium text-center px-4">
              Toque para fotografar a etiqueta
            </span>
          </div>

          <p className="text-sm text-muted-foreground text-center max-w-xs">
            Posicione a câmera para capturar a etiqueta da encomenda
          </p>
        </div>
      )}

      {step === 'processing' && (
        <div className="flex-1 flex flex-col items-center justify-center space-y-6 py-8">
          <Loader2 className="w-16 h-16 text-primary animate-spin" />
          <div className="text-center">
            <p className="text-lg font-medium">Lendo etiqueta...</p>
            <p className="text-sm text-muted-foreground mt-1">
              Identificando destinatário automaticamente
            </p>
          </div>
        </div>
      )}

      {step === 'confirm' && (
        <div className="space-y-6 pb-24">
          <Button
            onClick={() => {
              setStep('capture');
              setPhotoFile(null);
              setPhotoPreview(null);
              setSelectedResident(null);
              setCarrier('');
              setNotes('');
              setAiSuggestion(null);
            }}
            variant="ghost"
            size="sm"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Nova foto
          </Button>

          {/* Photo Preview */}
          <Card>
            <CardContent className="p-4">
              <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                <img
                  src={photoPreview!}
                  alt="Encomenda"
                  className="w-full h-full object-contain"
                />
              </div>
            </CardContent>
          </Card>

          {/* AI Suggestion Indicator */}
          {aiSuggestion && (
            <div className="flex items-center gap-2 text-sm text-primary bg-primary/10 px-4 py-2 rounded-lg">
              <Sparkles className="w-4 h-4" />
              <span>Dados sugeridos pela IA</span>
            </div>
          )}

          {/* Resident Selection */}
          <div className="space-y-2">
            <Label>Morador</Label>
            <Popover open={residentSearchOpen} onOpenChange={setResidentSearchOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full justify-between h-12 text-left font-normal"
                >
                  {selectedResident ? (
                    <span>
                      {selectedResident.full_name} - {selectedResident.block}/{selectedResident.apartment}
                    </span>
                  ) : (
                    <span className="text-muted-foreground">Selecionar morador...</span>
                  )}
                  <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0" align="start">
                <Command>
                  <CommandInput placeholder="Buscar morador..." />
                  <CommandList>
                    <CommandEmpty>Nenhum morador encontrado.</CommandEmpty>
                    <CommandGroup>
                      {residents.map((resident) => (
                        <CommandItem
                          key={resident.id}
                          onSelect={() => {
                            setSelectedResident(resident);
                            setResidentSearchOpen(false);
                          }}
                        >
                          <div className="flex flex-col">
                            <span>{resident.full_name}</span>
                            <span className="text-sm text-muted-foreground">
                              {resident.block}/{resident.apartment}
                            </span>
                          </div>
                          {selectedResident?.id === resident.id && (
                            <Check className="ml-auto h-4 w-4" />
                          )}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {/* Carrier */}
          <div className="space-y-2">
            <Label htmlFor="carrier">Transportadora (opcional)</Label>
            <Input
              id="carrier"
              value={carrier}
              onChange={(e) => setCarrier(e.target.value)}
              placeholder="Ex: Correios, Jadlog..."
              className="h-12"
            />
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Observações (opcional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Informações adicionais..."
              rows={3}
            />
          </div>

          {/* Submit Button */}
          <div className="fixed bottom-20 left-0 right-0 p-4 bg-gradient-to-t from-background via-background to-transparent md:relative md:bottom-auto md:p-0 md:bg-transparent">
            <Button
              onClick={handleSubmit}
              className="w-full h-14 text-lg"
              disabled={isSaving}
            >
              {isSaving ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Check className="w-5 h-5 mr-2" />
                  Confirmar recebimento
                </>
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
