import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

/**
 * Hook to generate signed URLs for private storage bucket files.
 * Returns a signed URL that expires after the specified duration.
 * 
 * @param bucket - The storage bucket name
 * @param path - The file path within the bucket (can be a full URL or just the path)
 * @param expiresIn - URL expiration time in seconds (default: 1 hour)
 */
export function useSignedUrl(
  bucket: string,
  path: string | null | undefined,
  expiresIn: number = 3600
): { signedUrl: string | null; loading: boolean; error: Error | null } {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!path) {
      setSignedUrl(null);
      return;
    }

    const generateSignedUrl = async () => {
      setLoading(true);
      setError(null);

      try {
        // Extract just the filename if a full URL was stored
        let filePath = path;
        
        // If it's a full URL, extract just the filename
        if (path.includes('/storage/v1/object/')) {
          const match = path.match(/\/storage\/v1\/object\/(?:public|sign)\/[^/]+\/(.+)/);
          if (match) {
            filePath = match[1];
          }
        }
        // Handle case where it might be stored with bucket prefix
        if (path.startsWith(`${bucket}/`)) {
          filePath = path.replace(`${bucket}/`, '');
        }

        const { data, error: signError } = await supabase.storage
          .from(bucket)
          .createSignedUrl(filePath, expiresIn);

        if (signError) {
          throw signError;
        }

        setSignedUrl(data?.signedUrl || null);
      } catch (err) {
        console.error('[useSignedUrl] Error generating signed URL:', err);
        setError(err instanceof Error ? err : new Error('Failed to generate signed URL'));
        setSignedUrl(null);
      } finally {
        setLoading(false);
      }
    };

    generateSignedUrl();
  }, [bucket, path, expiresIn]);

  return { signedUrl, loading, error };
}

/**
 * Utility function to generate a signed URL (non-hook version for edge functions)
 */
export async function getSignedUrl(
  bucket: string,
  path: string,
  expiresIn: number = 3600
): Promise<string | null> {
  try {
    let filePath = path;
    
    if (path.includes('/storage/v1/object/')) {
      const match = path.match(/\/storage\/v1\/object\/(?:public|sign)\/[^/]+\/(.+)/);
      if (match) {
        filePath = match[1];
      }
    }
    if (path.startsWith(`${bucket}/`)) {
      filePath = path.replace(`${bucket}/`, '');
    }

    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(filePath, expiresIn);

    if (error) {
      console.error('[getSignedUrl] Error:', error);
      return null;
    }

    return data?.signedUrl || null;
  } catch (err) {
    console.error('[getSignedUrl] Error:', err);
    return null;
  }
}
