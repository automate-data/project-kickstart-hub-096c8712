import { useEffect, useRef, useState, forwardRef, useImperativeHandle } from 'react';
import { Canvas as FabricCanvas, PencilBrush } from 'fabric';

interface SignatureCanvasProps {
  onSignatureChange?: (hasSignature: boolean) => void;
}

export interface SignatureCanvasRef {
  getSignatureData: () => string | null;
  clear: () => void;
  isEmpty: () => boolean;
}

export const SignatureCanvas = forwardRef<SignatureCanvasRef, SignatureCanvasProps>(
  ({ onSignatureChange }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [fabricCanvas, setFabricCanvas] = useState<FabricCanvas | null>(null);
    const [hasSignature, setHasSignature] = useState(false);

    useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = new FabricCanvas(canvasRef.current, {
        width: 320,
        height: 150,
        backgroundColor: '#ffffff',
        isDrawingMode: true,
      });

      // Configure drawing brush
      canvas.freeDrawingBrush = new PencilBrush(canvas);
      canvas.freeDrawingBrush.color = '#1a1a2e';
      canvas.freeDrawingBrush.width = 2;

      // Track when user draws
      canvas.on('path:created', () => {
        setHasSignature(true);
        onSignatureChange?.(true);
      });

      setFabricCanvas(canvas);

      return () => {
        canvas.dispose();
      };
    }, [onSignatureChange]);

    useImperativeHandle(ref, () => ({
      getSignatureData: () => {
        if (!fabricCanvas || !hasSignature) return null;
        return fabricCanvas.toDataURL({
          format: 'png',
          quality: 0.8,
          multiplier: 1,
        });
      },
      clear: () => {
        if (fabricCanvas) {
          fabricCanvas.clear();
          fabricCanvas.backgroundColor = '#ffffff';
          fabricCanvas.renderAll();
          setHasSignature(false);
          onSignatureChange?.(false);
        }
      },
      isEmpty: () => !hasSignature,
    }));

    return (
      <div className="w-full">
        <div className="border-2 border-dashed border-muted-foreground/30 rounded-lg overflow-hidden bg-white">
          <canvas ref={canvasRef} className="touch-none" />
        </div>
        {hasSignature && (
          <button
            type="button"
            onClick={() => {
              fabricCanvas?.clear();
              fabricCanvas!.backgroundColor = '#ffffff';
              fabricCanvas?.renderAll();
              setHasSignature(false);
              onSignatureChange?.(false);
            }}
            className="text-sm text-muted-foreground mt-2 underline"
          >
            Limpar assinatura
          </button>
        )}
      </div>
    );
  }
);

SignatureCanvas.displayName = 'SignatureCanvas';
