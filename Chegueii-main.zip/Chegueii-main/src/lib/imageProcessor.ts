/**
 * Image Processor for WhatsApp Business API Compatibility
 * 
 * Ensures all images meet WhatsApp requirements:
 * - Format: JPEG (.jpg)
 * - Max dimension: 1600px
 * - Max size: 1MB
 * - No EXIF metadata (canvas removes it)
 * - Non-progressive JPEG
 */

export interface ProcessedImage {
  blob: Blob;
  fileName: string;
  width: number;
  height: number;
  sizeKB: number;
}

const MAX_DIMENSION = 1600;
const MAX_SIZE_KB = 1000;
const INITIAL_QUALITY = 0.85;
const MIN_QUALITY = 0.5;

/**
 * Creates an HTMLImageElement from a File
 */
function createImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(img.src);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(img.src);
      reject(new Error('Failed to load image'));
    };
    img.src = URL.createObjectURL(file);
  });
}

/**
 * Converts canvas to JPEG blob with specified quality
 */
function canvasToJpegBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) {
          resolve(blob);
        } else {
          reject(new Error('Failed to create blob'));
        }
      },
      'image/jpeg',
      quality
    );
  });
}

/**
 * Processes an image file to be compatible with WhatsApp Business API
 * 
 * - Converts any format to JPEG
 * - Resizes to max 1600px maintaining aspect ratio
 * - Compresses to < 1MB
 * - Removes EXIF metadata (automatic via canvas)
 * - Generates standardized filename: encomenda_{timestamp}.jpg
 */
export async function processImageForWhatsApp(file: File): Promise<ProcessedImage> {
  console.log('[ImageProcessor] Starting processing:', file.name, file.type, `${Math.round(file.size / 1024)}KB`);

  // Create image from file
  const img = await createImageFromFile(file);
  console.log('[ImageProcessor] Original dimensions:', img.naturalWidth, 'x', img.naturalHeight);

  // Calculate new dimensions maintaining aspect ratio
  let width = img.naturalWidth;
  let height = img.naturalHeight;

  if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
    if (width > height) {
      height = Math.round((height * MAX_DIMENSION) / width);
      width = MAX_DIMENSION;
    } else {
      width = Math.round((width * MAX_DIMENSION) / height);
      height = MAX_DIMENSION;
    }
    console.log('[ImageProcessor] Resized to:', width, 'x', height);
  }

  // Create canvas and draw image (automatically removes EXIF)
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Could not get canvas context');
  }

  // Fill with white background (in case of transparent images)
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, height);
  
  // Draw the image
  ctx.drawImage(img, 0, 0, width, height);

  // Compress with progressive quality reduction if needed
  let quality = INITIAL_QUALITY;
  let blob: Blob;

  do {
    blob = await canvasToJpegBlob(canvas, quality);
    console.log('[ImageProcessor] Quality:', quality.toFixed(2), 'Size:', Math.round(blob.size / 1024), 'KB');
    
    if (blob.size <= MAX_SIZE_KB * 1024) {
      break;
    }
    
    quality -= 0.05;
  } while (quality >= MIN_QUALITY);

  // If still too large after min quality, reduce dimensions further
  if (blob.size > MAX_SIZE_KB * 1024) {
    console.log('[ImageProcessor] Still too large, reducing dimensions');
    const scale = 0.8;
    canvas.width = Math.round(width * scale);
    canvas.height = Math.round(height * scale);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    blob = await canvasToJpegBlob(canvas, MIN_QUALITY);
    width = canvas.width;
    height = canvas.height;
  }

  // Generate standardized filename
  const timestamp = Date.now();
  const fileName = `encomenda_${timestamp}.jpg`;

  const result: ProcessedImage = {
    blob,
    fileName,
    width,
    height,
    sizeKB: Math.round(blob.size / 1024)
  };

  console.log('[ImageProcessor] Final result:', result);
  return result;
}
