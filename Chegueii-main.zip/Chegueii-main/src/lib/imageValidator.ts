/**
 * Image Validator for WhatsApp Business API
 * 
 * Validates that a public image URL meets all requirements:
 * - HTTP 200 response (no redirects)
 * - Content-Type: image/jpeg
 * - Directly accessible (no auth, no cookies)
 */

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Validates a public image URL for WhatsApp Business API compatibility
 * 
 * Checks:
 * - URL responds with HTTP 200
 * - Content-Type is image/jpeg
 * - No redirections
 * - Image can be loaded successfully
 */
export async function validateImageForWhatsApp(url: string): Promise<ValidationResult> {
  const errors: string[] = [];

  try {
    console.log('[ImageValidator] Validating URL:', url);

    // Fetch with redirect manual to detect redirections
    const response = await fetch(url, {
      method: 'GET',
      redirect: 'manual'
    });

    // Check for redirects (3xx status codes)
    if (response.status >= 300 && response.status < 400) {
      errors.push(`URL usa redirecionamento (HTTP ${response.status}) - não permitido`);
      return { valid: false, errors };
    }

    // Check HTTP 200
    if (response.status !== 200) {
      errors.push(`HTTP ${response.status} - URL não acessível`);
      return { valid: false, errors };
    }

    // Check Content-Type
    const contentType = response.headers.get('content-type');
    console.log('[ImageValidator] Content-Type:', contentType);
    
    if (!contentType || !contentType.includes('image/jpeg')) {
      errors.push(`Content-Type inválido: ${contentType || 'não definido'} (esperado: image/jpeg)`);
    }

    // Try to load as image to verify it's valid
    const blob = await response.blob();
    console.log('[ImageValidator] Blob size:', Math.round(blob.size / 1024), 'KB');

    // Verify the blob is actually a valid image
    await new Promise<void>((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(img.src);
        resolve();
      };
      img.onerror = () => {
        URL.revokeObjectURL(img.src);
        reject(new Error('Imagem não pode ser decodificada'));
      };
      img.src = URL.createObjectURL(blob);
    });

    console.log('[ImageValidator] Image loaded successfully');

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    errors.push(`Erro ao validar: ${errorMessage}`);
    console.error('[ImageValidator] Validation error:', error);
  }

  const result: ValidationResult = {
    valid: errors.length === 0,
    errors
  };

  console.log('[ImageValidator] Result:', result);
  return result;
}
