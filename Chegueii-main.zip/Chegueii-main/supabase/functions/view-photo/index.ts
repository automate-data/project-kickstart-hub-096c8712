import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  try {
    const url = new URL(req.url);
    const file = url.searchParams.get("file");

    if (!file) {
      return new Response("Missing file parameter", { status: 400 });
    }

    // Sanitize: only allow simple filenames (no path traversal)
    if (file.includes("..") || file.includes("/")) {
      return new Response("Invalid file parameter", { status: 400 });
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data, error } = await supabaseAdmin.storage
      .from("package-photos")
      .createSignedUrl(file, 604800); // 7 days

    if (error || !data?.signedUrl) {
      console.error("Failed to generate signed URL:", error);
      return new Response("Image not found", { status: 404 });
    }

    return new Response(null, {
      status: 302,
      headers: { Location: data.signedUrl },
    });
  } catch (err) {
    console.error("Error:", err);
    return new Response("Internal error", { status: 500 });
  }
});
