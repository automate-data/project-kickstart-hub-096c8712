import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate and authorize the request
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      console.error("Missing or invalid Authorization header");
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      console.error("Invalid JWT:", claimsError);
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub;

    // Verify user has staff role
    const { data: roleData, error: roleError } = await supabaseClient
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .maybeSingle();

    if (roleError || !roleData) {
      console.error("User does not have staff role:", userId);
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { image_base64 } = await req.json();
    console.log('[process-label] Recebida imagem para processamento, tamanho base64:', image_base64?.length || 0, 'requestedBy:', userId);
    
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `Você é um especialista em leitura de etiquetas de encomendas brasileiras de condomínios. Analise cuidadosamente a imagem e extraia TODAS as informações visíveis.

INSTRUÇÕES CRÍTICAS PARA BLOCO E APARTAMENTO:
- Formatos condensados: "B01", "A53", "B1", "A-53" = bloco é a LETRA (B ou A), apartamento são os NÚMEROS (01, 53, 1)
- "B01" significa Bloco B, Apartamento 01 - SEPARE EM DOIS CAMPOS!
- "casa 801", "apt 801", "apartamento 801" = apartamento é 801
- "BLOCO A APTO 53", "Bloco A - 53", "BL A AP 53" = bloco é A, apartamento é 53
- Se aparecer apenas número de 2-3 dígitos (ex: 53, 101), é o apartamento
- Números de 4+ dígitos podem ser apartamentos de andares altos (ex: 1201)
- SEMPRE separe bloco e apartamento, mesmo quando aparecem juntos
- Se não conseguir identificar o bloco, deixe vazio, mas SEMPRE tente extrair o apartamento

INSTRUÇÕES PARA NOME DO DESTINATÁRIO:
- O nome geralmente aparece em destaque, às vezes duplicado (no topo e como "RECEBEDOR" ou "DESTINATÁRIO")
- Extraia o nome COMPLETO, incluindo sobrenomes
- Ignore títulos como "Sr.", "Sra.", "Dr."
- Se houver "A/C" ou "Aos cuidados de", pegue o nome após isso

OUTRAS INFORMAÇÕES:
- Procure por logos de transportadoras: Jadlog, Correios, Total Express, Loggi, Azul Cargo, FedEx, DHL
- Procure por logos de marketplaces: TikTok Shop, Mercado Livre, Amazon, Shopee, Shein, AliExpress, Magazine Luiza
- O peso geralmente aparece como "Weight" ou "Peso" seguido de valor em KG
- O código de rastreio é um número longo (geralmente 13+ caracteres)
- Procure por "CD" (Centro de Distribuição) que indica origem logística

FORMATO DE RESPOSTA - Retorne APENAS JSON válido:
{
  "resident_name": "nome completo do destinatário",
  "block": "APENAS a letra ou número do bloco (ex: A, B, 1, 2) - extraído de formatos como B01, Bloco A, etc",
  "apartment": "APENAS o número do apartamento (ex: 01, 53, 101, 801) - sem letras ou prefixos",
  "unit": "bloco + apartamento como aparecem na etiqueta (ex: B01, A-53)",
  "carrier": "nome da transportadora",
  "marketplace": "nome do marketplace se visível",
  "tracking_code": "código de rastreio",
  "weight_kg": 0.0,
  "logistics_origin": "origem logística se visível",
  "confidence": 0.0
}`
          },
          {
            role: 'user',
            content: [
              { type: 'text', text: 'Analise esta etiqueta de encomenda brasileira de condomínio. IMPORTANTE: Separe BLOCO e APARTAMENTO em campos distintos. Se a etiqueta mostrar "B01", extraia bloco="B" e apartment="01". Preste atenção especial ao nome completo do destinatário.' },
              { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${image_base64}` } }
            ]
          }
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[process-label] AI Gateway error:', response.status, errorText);
      throw new Error('AI processing failed');
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';
    console.log('[process-label] Resposta bruta da IA:', content);
    
    let suggestion = {};
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        suggestion = JSON.parse(jsonMatch[0]);
        console.log('[process-label] JSON parseado:', JSON.stringify(suggestion));
        
        // Post-processing: extrair bloco e apartamento de formatos condensados
        const rawBlock = (suggestion as any).block || '';
        const rawApartment = (suggestion as any).apartment || '';
        const rawUnit = (suggestion as any).unit || '';
        
        // Se block ainda contém números, separar
        if (rawBlock && /^[A-Za-z]\d+$/.test(rawBlock)) {
          const match = rawBlock.match(/^([A-Za-z])(\d+)$/);
          if (match) {
            (suggestion as any).block = match[1].toUpperCase();
            if (!rawApartment || rawApartment === rawBlock) {
              (suggestion as any).apartment = match[2];
            }
          }
        }
        
        // Se apartment está vazio mas unit tem informação, tentar extrair
        if (!rawApartment && rawUnit) {
          const unitMatch = rawUnit.match(/([A-Za-z])?[-\s]?(\d+)/);
          if (unitMatch) {
            if (unitMatch[1] && !(suggestion as any).block) {
              (suggestion as any).block = unitMatch[1].toUpperCase();
            }
            (suggestion as any).apartment = unitMatch[2];
          }
        }
        
        // Limpar apartment removendo zeros à esquerda desnecessários
        if ((suggestion as any).apartment) {
          const apt = String((suggestion as any).apartment).replace(/^0+(?=\d)/, '');
          (suggestion as any).apartment = apt || (suggestion as any).apartment;
        }
        
        // Normalizar bloco para maiúscula
        if ((suggestion as any).block) {
          (suggestion as any).block = String((suggestion as any).block).toUpperCase().replace(/[^A-Z0-9]/g, '');
        }
        
        console.log('[process-label] Após pós-processamento:', JSON.stringify(suggestion));
      }
    } catch (e) {
      console.error('[process-label] Erro ao parsear resposta da IA:', e, 'Conteúdo:', content);
    }

    return new Response(JSON.stringify({ suggestion, raw_text: content }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('[process-label] Erro geral:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
