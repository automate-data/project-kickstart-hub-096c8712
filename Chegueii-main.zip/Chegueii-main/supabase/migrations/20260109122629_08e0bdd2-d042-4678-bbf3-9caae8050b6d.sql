-- Fix 1: Make package-photos bucket private
UPDATE storage.buckets SET public = false WHERE id = 'package-photos';

-- Remove the public SELECT policy
DROP POLICY IF EXISTS "Anyone can view package photos" ON storage.objects;

-- Add staff-only SELECT policy for package photos
CREATE POLICY "Staff can view package photos"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'package-photos' AND public.is_staff(auth.uid()));

-- Ensure INSERT policy exists for staff
DROP POLICY IF EXISTS "Staff can upload package photos" ON storage.objects;
CREATE POLICY "Staff can upload package photos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'package-photos' AND public.is_staff(auth.uid()));

-- Ensure UPDATE policy exists for staff
DROP POLICY IF EXISTS "Staff can update package photos" ON storage.objects;
CREATE POLICY "Staff can update package photos"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'package-photos' AND public.is_staff(auth.uid()));