-- Create storage bucket for package photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('package-photos', 'package-photos', true);

-- Allow authenticated users to upload photos
CREATE POLICY "Staff can upload package photos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'package-photos');

-- Allow public read access for photos
CREATE POLICY "Anyone can view package photos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'package-photos');

-- Allow staff to delete photos
CREATE POLICY "Staff can delete package photos"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'package-photos');