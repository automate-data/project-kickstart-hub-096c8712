-- Create function to make first user admin
CREATE OR REPLACE FUNCTION public.make_first_user_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    admin_count INTEGER;
BEGIN
    -- Check if there are any admins
    SELECT COUNT(*) INTO admin_count FROM public.user_roles WHERE role = 'admin';
    
    -- If no admins exist, make this user an admin
    IF admin_count = 0 THEN
        INSERT INTO public.user_roles (user_id, role)
        VALUES (NEW.id, 'admin');
    END IF;
    
    RETURN NEW;
END;
$$;

-- Trigger to run after profile is created
CREATE TRIGGER on_first_user_make_admin
    AFTER INSERT ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.make_first_user_admin();