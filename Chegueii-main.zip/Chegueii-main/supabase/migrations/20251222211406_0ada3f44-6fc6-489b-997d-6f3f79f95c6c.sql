-- Add signature_data column to packages table for storing pickup signatures
ALTER TABLE public.packages ADD COLUMN IF NOT EXISTS signature_data TEXT;

-- Add pickup_confirmation_sent column for audit trail
ALTER TABLE public.packages ADD COLUMN IF NOT EXISTS pickup_confirmation_sent BOOLEAN DEFAULT FALSE;